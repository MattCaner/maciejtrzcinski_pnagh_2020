#include<stdio.h>

int function(int i){
	return i+10;
}

const char* text = "Important debug info!";

int main(){

	printf("Hello binutils!\n5+10=%d\ntext=%s\n",function(5),text);
	return 0;
}
