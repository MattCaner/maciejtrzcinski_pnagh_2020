#include<stdio.h>

int multiply_number(int n){
	if(n>1000) printf("This number is too large!\n");
	else return n*1000;
}
