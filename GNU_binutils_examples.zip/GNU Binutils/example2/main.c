#include<stdio.h>

extern double density_of_air;
extern double g;

const char* header_text = "CALCULATING BUOYANCY!";
const double _pi = 3.141592;
double* unitialized_pointer;

double buoyancy(double V, double ro, double g){
	return ro*g*V;
}

double volume_of_a_sphere(double radius){
	return  4./3.*_pi*radius*radius*radius;
}

int main(){
	double volume = volume_of_a_sphere(20.);
	printf("Buoyancy of our volume in air = %g\n",buoyancy(volume,density_of_air,g));
	return 0;
}
