#include<stdio.h>

int fun(int i);

int main(){

	
	printf("Hello gold!\nFun of 5=%d\n",fun(5));
	return 0;
}
