int fun(int i){
	return i+10;
}

