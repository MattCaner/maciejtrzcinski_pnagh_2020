int main(){
	int x = fun(10);
	printf("x=%d\n",x);
	return 0;
}
