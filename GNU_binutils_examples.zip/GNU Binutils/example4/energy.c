const double _g = 9.81;

double pe(double mass, double height){
	return mass*height*_g;
}
