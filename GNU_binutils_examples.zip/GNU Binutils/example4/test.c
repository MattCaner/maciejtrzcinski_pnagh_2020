#include<stdio.h>

extern double _g;
double pe(double,double);

int main(){

	double mass = 100.;
	double height = 1.;

	double energy = pe(mass,height);

	printf("Gravitational acceleration = %g m*s^-2\nPotential energy of a body = %g J\n",_g,energy);

	return 0;
}
